const path = require('path');

module.exports = {
  entry: ['babel-polyfill', './src/index.js'],
  mode: process.env.NODE_ENV || 'development',
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'babel-loader',
        options: { presets: ['@babel/env'] }
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      }
    ]
  },
  resolve: { extensions: ['*', '.js'] },
  output: {
    path: path.resolve(__dirname),
    publicPath: path.resolve(__dirname),
    filename: 'app.js'
  },
  optimization: {
    removeEmptyChunks: true
  }
};
